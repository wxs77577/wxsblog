<?php
/* $Id: info.inc.php,v 2.4 2005/11/24 07:15:55 cybot_tm Exp $ */
/* Theme information */
$theme_name = 'Original';
$theme_version = 2;
$theme_generation = 2;
$theme_full_version = '2.7.0.0';
?>
